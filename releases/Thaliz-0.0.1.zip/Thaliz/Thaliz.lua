﻿--[[
	Author:			Mimma
	Create Date:	5/10/2015 5:50:57 PM
	
	Dependencies:
	* MimmaTimers.lua
]]

local PARTY_CHANNEL = "PARTY"
local RAID_CHANNEL = "RAID"
local WARN_CHANNEL = "RAID_WARNING"
local GUILD_CHANNEL = "GUILD"
local CHAT_END = "|r"
local COLOUR_CHAT = "|c8000FFFF"
local THALIZ_PREFIX = "Thalizv1"

--	List of valid class names
local classInfo = {
	{ "Druid",   25, nil },
	{ "Hunter",  20, nil },
	{ "Mage",    25, nil },
	{ "Paladin", 30, "Redemption" },
	{ "Priest",  30, "Resurrection" },
	{ "Rogue",   10, nil },
	{ "Shaman",  30, "Ancestral Spirit" },
	{ "Warlock", 20, nil },
	{ "Warrior", 15, nil }
}
--todo: downprioritize afk people

-- redemption: 1209 mana
-- redurrection: 1077 mana
-- ancestral spirit: ? mana


local corpseTable = {}
local blacklistedTable = {}


--[[
	Must be configurable:
]]
-- List of resurrection messages
local ResurrectionMessages = {
	"Resurrecting --> %s",
	"Get Up, %s",
	"Stop slacking, %s!",
	"Oops, seems %s ran out of health!",
	"Get back to life, %s"
}
-- Corpses are blacklisted for 30 seconds as default
local Thaliz_Blacklist_Timeout = 30;





--[[
	Scan # of dead people (debug function)
	Syntax: /thaliz
]]
SLASH_SCAN_DEAD1 = "/thaliz"
SlashCmdList["SCAN_DEAD"] = function(msg)
	local _, _, name, dkp = string.find(msg, "(%S*)%s*(%d*).*")

	scanDeadPeople();

end




function scanDeadPeople()
	-- Check by spell: no need to update death list if player cannot resurrect!
	local classinfo = GetClassinfo(UnitClass("player"));
	local spellname = classinfo[3];
	if not spellname then
		return;
	end
		
	corpseTable = {};

	local groupsize = GetNumPartyMembers();
	if groupsize == 0 then
		echo("<Thaliz> You are not in a group!");
		return;
	end

	local grouptype = "party";
	if isInRaid() then
		groupsize = GetNumRaidMembers();
		grouptype = "raid";
	end

	-- Remove expired people from blacklist:
	local BlacklistedTableNew = {}
	local blacklistInfo, blacklistTick;
	local timerTick = GetTimerTick();
	for b=1, table.getn(blacklistedTable), 1 do
		blacklistInfo = blacklistedTable[b];
		blacklistTick = blacklistInfo[2];
		if timerTick < blacklistTick then
			BlacklistedTableNew[ table.getn(BlacklistedTableNew) + 1 ] = blacklistInfo;
		end
	end
	blacklistedTable = BlacklistedTableNew;

	local playername, unitid, classinfo;
	for n=1, groupsize, 1 do
		unitid = grouptype..n
		playername = UnitName(unitid)
		
		local isBlacklisted = false;
		for b=1, table.getn(blacklistedTable), 1 do
			blacklistInfo = blacklistedTable[b];
			blacklistTick = blacklistInfo[2];					
			if blacklistInfo[1] == playername then
				isBlacklisted = true;
				break;
			end
		end
		
		if not isBlacklisted and UnitIsDead(unitid) and UnitIsConnected(unitid) and UnitIsVisible(unitid) then
			classinfo = GetClassinfo(UnitClass(unitid));
			corpseTable[ table.getn(corpseTable) + 1 ] = { unitid, classinfo[2] } ;
		end
	end	

	if (table.getn(corpseTable) == 0) then
		echo("<Thaliz> There are no one to ress.");
		return;
	end

	-- Sort the corpses with highest priority in top:
	sortTableDescending(corpseTable, 2);

	-- Start casting the spell:	
	CastSpellByName(spellname);
	local unitid = ChooseCorpse();	
	if unitid then
		playername = UnitName(unitid)
		
		SpellTargetUnit(unitid);

		if not SpellIsTargeting() then
			announceResurrection(playername);
			blacklistedTable[ table.getn(blacklistedTable) + 1 ] = { playername, GetTimerTick() + Thaliz_Blacklist_Timeout };
		else
			SpellStopTargeting();
		end
	else
		SpellStopTargeting();
		--Not in range. UI already write that, we dont need to!
	end
end


function ChooseCorpse()
	for key, val in corpseTable do
		if SpellCanTargetUnit(val[1]) then
			return val[1];
		end
	end
	return nil;
end



function GetClassinfo(classname)
	for key, val in classInfo do
		if val[1] == classname then
			return val;
		end
	end
	return nil;
end


function sortTableDescending(sourcetable, index)
	local doSort = true
	while doSort do
		doSort = false
		for n=1,table.getn(sourcetable) - 1,1 do
			local a = sourcetable[n]
			local b = sourcetable[n + 1]
			if tonumber(a[index]) and tonumber(b[index]) and tonumber(a[index]) < tonumber(b[index]) then
				sourcetable[n] = b
				sourcetable[n + 1] = a
				doSort = true
			end
		end
	end
end


function announceResurrection(playername)
	local msgCount = table.getn( ResurrectionMessages );	
	local message = string.format(ResurrectionMessages[ random(msgCount) ], playername);
	
	partyEcho(message);
end



--[[
	Echo a message for the local user only.
]]
function echo(msg)
	if not msg then
		msg = ""
	end
	DEFAULT_CHAT_FRAME:AddMessage(COLOUR_CHAT .. msg .. CHAT_END)
end

--[[
	Echo in raid chat (if in raid) or Guild chat (if not)
]]
function rcEcho(msg)
	if isInRaid(true) then
		SendChatMessage(msg, RAID_CHANNEL)
	else
		gcEcho(msg)
	end
end



function partyEcho(msg)
	if GetNumPartyMembers() > 0 then
		if isInRaid(false) then
			SendChatMessage(msg, RAID_CHANNEL)
		else
			SendChatMessage(msg, PARTY_CHANNEL)
		end
	end
end



local Timers = {}
local TimerTick = 0

function OnTimer(elapsed)
	TimerTick = TimerTick + elapsed

	for n=1,table.getn(Timers),1 do
		local timer = Timers[n]
		if TimerTick > timer[2] then
			Timers[n] = nil
			timer[1]()
		end
	end
end

function GetTimerTick()
	return TimerTick;
end

function AddTimer( method, duration )
	Timers[table.getn(Timers) + 1] = { method, TimerTick + duration }
end




function Thaliz_OnLoad()
	echo("Thaliz version " .. GetAddOnMetadata("Thaliz", "Version") .. " by ".. GetAddOnMetadata("Thaliz", "Author"))

    --this:RegisterEvent("CHAT_MSG_ADDON")
end



function Thaliz_OnEvent(event)
end

