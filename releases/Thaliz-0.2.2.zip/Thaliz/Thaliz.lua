﻿--[[
	Author:			Mimma
	Create Date:	5/10/2015 5:50:57 PM
]]

local PARTY_CHANNEL = "PARTY"
local RAID_CHANNEL  = "RAID"
local WARN_CHANNEL  = "RAID_WARNING"
local GUILD_CHANNEL = "GUILD"
local CHAT_END      = "|r"
local COLOUR_CHAT   = "|c8010D0FF"
local COLOUR_INTRO  = "|c80B040F0"
local THALIZ_PREFIX = "Thalizv1"
local CTRA_PREFIX   = "CTRA"

--	List of valid class names with priority and resurrection spell name (if any)
local classInfo = {
	{ "Druid",   40, nil },
	{ "Hunter",  30, nil },
	{ "Mage",    40, nil },
	{ "Paladin", 50, "Redemption" },
	{ "Priest",  50, "Resurrection" },
	{ "Rogue",   10, nil },
	{ "Shaman",  50, "Ancestral Spirit" },
	{ "Warlock", 30, nil },
	{ "Warrior", 20, nil }
}

local PriorityToFirstWarlock  = 45;     -- Prio below ressers if no warlocks are alive
local PriorityToGroupLeader   = 45;     -- Prio below ressers if raid leader or assistant
local PriorityToCurrentTarget = 100;	-- Prio over all if target is selected

-- List of corpses (dead people)
local corpseTable = {}
-- List of blacklisted (already ressed) people
local blacklistedTable = {}


--
--  Configurable options:
--

-- List of resurrection messages
local ResurrectionMessages = {
	"(Ressing) Stop slacking and get up, %s!",
	"(Ressing) How many \'Z\'s are in Vaelastrasz, %s?",
	"(Ressing) Did you just do the unsafety dance, %s?",

	"(Ressing) I\'m keeping my eye on you, %s!",
	"(Ressing) Too soon, %s - you have died too soon!",
	"(Ressing) Cower, %s! The age of darkness is at hand!",
	"(Ressing) %s! Death! Destruction!",
	"(Ressing) No more play, %s?",
	"(Ressing) Forgive me %s, your death only adds to my failure.",
	"(Ressing) Your friends will abandon you, %s!",
	"(Ressing) Slay %s in the masters name!",

	"(Ressing) %s, Chuck Norris would have survived that!",
	"(Ressing) %s, seems you ran out of health!",
	"(Ressing) %s, you make the floor look dirty!",
	"(Ressing) %s, there\'s loot waiting for you!"
}
-- Corpses are blacklisted for 30 seconds as default
local Thaliz_Blacklist_Timeout = 30;




--  *******************************************************
--
--	Slash commands
--
--  *******************************************************

--[[
	Scan # of dead people (debug function)
	Syntax: /thaliz
]]
SLASH_SCAN_DEAD1 = "/thaliz"
SlashCmdList["SCAN_DEAD"] = function(msg)
	local _, _, name, dkp = string.find(msg, "(%S*)%s*(%d*).*")

	scanDeadPeople();

end

--[[
	Scan # of dead people (debug function)
	Syntax: /thalizversion
]]
SLASH_VERSION1 = "/thalizversion"
SlashCmdList["VERSION"] = function(msg)
	Thaliz_SendAddonMessage("TX_VERSION##");
end



--  *******************************************************
--
--	Ressing functions
--
--  *******************************************************

--[[
	Scan the part / raid for dead people, and prioritize those.
	Ignore blacklisted people.
	Only do this is the current player is a resser!
]]
function scanDeadPeople()
	-- Check by spell: no need to update death list if player cannot resurrect!
	local classinfo = GetClassinfo(UnitClass("player"));
	local spellname = classinfo[3];
	if not spellname then
		return;
	end
		
	corpseTable = {};
	CleanupBlacklistedPlayers();

	local groupsize, grouptype;
	if IsInRaid() then
		groupsize = GetNumRaidMembers();
		grouptype = "raid";	
	elseif IsInParty() then
		groupsize = GetNumPartyMembers();
		grouptype = "party";
	else
		Thaliz_Echo("You are not in a group!");
		return;
	end
	
	local warlocksAlive = false;
	for n=1, groupsize, 1 do
		unitid = grouptype..n
		if not UnitIsDead(unitid) and UnitIsConnected(unitid) and UnitIsVisible(unitid) and UnitClass(unitid) == "Warlock" then
			warlocksAlive = true;
			break;
		end
	end
	
		
	local playername, unitid, classinfo;
	for n=1, groupsize, 1 do
		unitid = grouptype..n
		playername = UnitName(unitid)
		
		local isBlacklisted = false;
		for b=1, table.getn(blacklistedTable), 1 do
			blacklistInfo = blacklistedTable[b];
			blacklistTick = blacklistInfo[2];					
			if blacklistInfo[1] == playername then
				isBlacklisted = true;
				break;
			end
		end
		
		
		local targetprio
		local targetname = UnitName("playertarget");
		if not isBlacklisted and UnitIsDead(unitid) and UnitIsConnected(unitid) and UnitIsVisible(unitid) then
			classinfo = GetClassinfo(UnitClass(unitid));
			targetprio = classinfo[2];
			if targetname and targetname == playername then
				targetprio = PriorityToCurrentTarget;
			end
			if IsRaidLeader(playername) and targetprio < PriorityToGroupLeader then
				targetprio = PriorityToGroupLeader;
			end
			if not warlocksAlive and classinfo[1] == "Warlock" then
				targetprio = PriorityToFirstWarlock;				
			end
			
			--echo(string.format("%s added, priority=%d", playername, targetprio));			
			corpseTable[ table.getn(corpseTable) + 1 ] = { unitid, targetprio } ;
		end
	end	

	if (table.getn(corpseTable) == 0) then
		if (table.getn(blacklistedTable) == 0) then		
			Thaliz_Echo("There is no one to resurrect.");
		else
			Thaliz_Echo("All targets have received a res.");
		end
		return;
	end

	-- Sort the corpses with highest priority in top:
	sortTableDescending(corpseTable, 2);

	-- Start casting the spell:	
	CastSpellByName(spellname);
	local unitid = ChooseCorpse();	
	if unitid then
		playername = UnitName(unitid)
		
		SpellTargetUnit(unitid);
		if not SpellIsTargeting() then
			BlacklistPlayer(playername);
			AnnounceResurrection(playername);
			Thaliz_SendAddonMessage("TX_RESBEGIN#"..playername.."#");
		else
			SpellStopTargeting();
		end
	else
		SpellStopTargeting();
		--Not in range. UI already write that, we dont need to also!
	end
end

function ChooseCorpse()
	for key, val in corpseTable do
		if SpellCanTargetUnit(val[1]) then
			return val[1];
		end
	end
	return nil;
end

function GetClassinfo(classname)
	for key, val in classInfo do
		if val[1] == classname then
			return val;
		end
	end
	return nil;
end



--  *******************************************************
--
--	Blacklisting functions
--
--  *******************************************************
function BlacklistPlayer(playername)
	blacklistedTable[ table.getn(blacklistedTable) + 1 ] = { playername, GetTimerTick() + Thaliz_Blacklist_Timeout };
end


function IsPlayerBlacklisted(playername)
	CleanupBlacklistedPlayers();

	for n=1, table.getn(blacklistedTable), 1 do		 
		if blacklistedTable[n][1] == playername then
			return true;
		end
	end
	return false;
end


function CleanupBlacklistedPlayers()
	local BlacklistedTableNew = {}
	local blacklistInfo, blacklistTick;	
	local timerTick = GetTimerTick();
	
	for n=1, table.getn(blacklistedTable), 1 do
		blacklistInfo = blacklistedTable[n];
		blacklistTick = blacklistInfo[2];
		if timerTick < blacklistTick then
			BlacklistedTableNew[ table.getn(BlacklistedTableNew) + 1 ] = blacklistInfo;
		end
	end
	blacklistedTable = BlacklistedTableNew;
end



--  *******************************************************
--
--	Helper functions
--
--  *******************************************************
function IsInParty()
	if not IsInRaid() then
		return ( GetNumPartyMembers() > 0 );
	end
	return false
end


function IsInRaid()
	return ( GetNumRaidMembers() > 0 );
end


function sortTableDescending(sourcetable, index)
	local doSort = true
	while doSort do
		doSort = false
		for n=1,table.getn(sourcetable) - 1,1 do
			local a = sourcetable[n]
			local b = sourcetable[n + 1]
			if tonumber(a[index]) and tonumber(b[index]) and tonumber(a[index]) < tonumber(b[index]) then
				sourcetable[n] = b
				sourcetable[n + 1] = a
				doSort = true
			end
		end
	end
end


function AnnounceResurrection(playername)
	--echo("Announcing resurrection on "..playername);

	local msgCount = table.getn( ResurrectionMessages );
	local message = string.format(ResurrectionMessages[ random(msgCount) ], playername);
	
	partyEcho(message);
end

--[[
	Echo a message for the local user only, including Thaliz "logo"
]]
function Thaliz_Echo(msg)
	echo("<"..COLOUR_INTRO.."THALIZ"..COLOUR_CHAT.."> "..msg);
end

--[[
	Echo a message for the local user only.
]]
function echo(msg)
	if not msg then
		msg = ""
	end
	DEFAULT_CHAT_FRAME:AddMessage(COLOUR_CHAT .. msg .. CHAT_END)
end

--[[
	Echo in raid chat (if in raid) or Guild chat (if not)
]]
function rcEcho(msg)
	if IsInRaid() then
		SendChatMessage(msg, RAID_CHANNEL)
	else
		gcEcho(msg)
	end
end

--[[
	Echo in raid chat (if in raid) or party chat (if not)
]]
function partyEcho(msg)
	if IsInRaid() then
		SendChatMessage(msg, RAID_CHANNEL)
	elseif IsInParty() then
		SendChatMessage(msg, PARTY_CHANNEL)
	end
end



--  *******************************************************
--
--	Timer functions
--
--  *******************************************************
local Timers = {}
local TimerTick = 0

function Thaliz_OnTimer(elapsed)
	TimerTick = TimerTick + elapsed

	for n=1,table.getn(Timers),1 do
		local timer = Timers[n]
		if TimerTick > timer[2] then
			Timers[n] = nil
			timer[1]()
		end
	end
end

function GetTimerTick()
	return TimerTick;
end

function AddTimer( method, duration )
	Timers[table.getn(Timers) + 1] = { method, TimerTick + duration }
end




--  *******************************************************
--
--	Internal Communication Functions
--
--  *******************************************************

function Thaliz_SendAddonMessage(message)
	local channel = nil
	
	if IsInRaid() then
		channel = "RAID";
	elseif IsInParty() then
		channel = "PARTY";
	end

	if channel then	
		SendAddonMessage(THALIZ_PREFIX, message, channel);
	end
end



--[[
	Respond to a TX_VERSION command.
	Input:
		msg is the raw message
		sender is the name of the message sender.
	We should whisper this guy back with our current version number.
	We therefore generate a response back (RX) in raid with the syntax:
	Thaliz:<sender (which is actually the receiver!)>:<version number>
]]
local function HandleTXVersion(message, sender)
	local response = GetAddOnMetadata("Thaliz", "Version")
	
	Thaliz_SendAddonMessage("RX_VERSION#"..response.."#"..sender)
end

local function HandleTXResBegin(message, sender)
	-- Blacklist target unless ress was initated by me
	if not (sender == UnitName("player")) then
		BlacklistPlayer(message);
	end
end

--[[
	A version response (RX) was received. The version information is displayed locally.
]]
local function HandleRXVersion(message, sender)
	Thaliz_Echo(string.format("%s is using Thaliz version %s", sender, message))
end


function Thaliz_OnChatMsgAddon(event, prefix, msg, channel, sender)
	if prefix == THALIZ_PREFIX then
		Thaliz_HandleThalizMessage(msg, sender);	
	end
	if prefix == CTRA_PREFIX then
		Thaliz_HandleCTRAMessage(msg, sender);
	end
end



function Thaliz_HandleThalizMessage(msg, sender)
	--echo(sender.." --> "..msg);

	local _, _, cmd, message, recipient = string.find(msg, "([^#]*)#([^#]*)#([^#]*)");	
	--	Ignore message if it is not for me. Receipient can be blank, which means it is for everyone.
	if not (recipient == "") then
		if not (recipient == UnitName("player")) then
			return
		end
	end

	if cmd == "TX_VERSION" then
		HandleTXVersion(message, sender)
	elseif cmd == "RX_VERSION" then
		HandleRXVersion(message, sender)
	elseif cmd == "TX_RESBEGIN" then
		HandleTXResBegin(message, sender)
	end
	
end

function Thaliz_HandleCTRAMessage(msg, sender)
	--echo("CTRA: ["..sender.."] --> ["..msg.."]");
	
	-- "RESSED" is received when a res LANDS on target.
	-- Add to blacklist.
	if msg == "RESSED" then
		BlacklistPlayer(sender);
		return;
	end
	
	-- "RES <name>" is received when a manual res is CASTED
	-- Add to blacklist.
	local _, _, ctra_command, ctra_player = string.find(msg, "(%S*) (%S*)");
	if ctra_command and ctra_player then
		if ctra_command == "RES" then
			-- If sender is from ME, it is ME doing a manual ress. Announce it!
			if sender == UnitName("player") then
				-- Check if player is online; for this we need the unit id!
				local unitid = nil;
				if IsInRaid() then
					for n=1, GetNumRaidMembers(), 1 do
						if UnitName("raid"..n) == ctra_player then
							unitid = "raid"..n;
							break;
						end
					end
				else
					for n=1, GetNumPartyMembers(), 1 do
						if UnitName("party"..n) == ctra_player then
							unitid = "party"..n;
							break;
						end
					end				
				end

				if unitid then
					if UnitIsConnected(unitid) then
						-- If unit is blacklisted we should NOT display the ress. message.
						-- Unfortunately we cannot cancel the spell cast.
						if not IsPlayerBlacklisted(ctra_player) then
							AnnounceResurrection(ctra_player);
						end
					else
						Thaliz_Echo(string.format("NOTE: %s is offline!", ctra_player));
					end
				end				
			end
			
			BlacklistPlayer(ctra_player);
			return;
		end
	end

	-- "RESNO" is received when a res is cancelled 
	-- Do nothing.
	
	-- "NORESSED" is received when res timeout OR res is accepted!
	-- Do nothing (the blacklist expires soon anyway)
end



--  *******************************************************
--
--	Event handlers
--
--  *******************************************************

function Thaliz_OnEvent(event)
	if (event == "CHAT_MSG_ADDON") then
		Thaliz_OnChatMsgAddon(event, arg1, arg2, arg3, arg4, arg5)
	end
end

function Thaliz_OnLoad()
	Thaliz_Echo(string.format("version %s by %s", GetAddOnMetadata("Thaliz", "Version"), GetAddOnMetadata("Thaliz", "Author")));
    this:RegisterEvent("CHAT_MSG_ADDON");
end

